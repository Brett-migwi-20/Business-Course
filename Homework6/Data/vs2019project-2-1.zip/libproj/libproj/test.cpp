#include "library.h"

void main()
{ make_window(600, 600);
  move_to(100, 100);
  draw_to(500, 500);
  write_string("string");
  print("All done"); }